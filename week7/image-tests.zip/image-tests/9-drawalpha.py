from PIL import Image
from PIL import ImageDraw

im = Image.new("RGB",(1000,500),(255,255,255,255))

circle = ImageDraw.Draw(im,'RGBA')

w = im.width
h = im.height

for x in range(0,w,20):
    for y in range(0,h,20):
        circle.ellipse( [x,y,x+30,y+30], fill=(0,100,200,50) )

im.show()
