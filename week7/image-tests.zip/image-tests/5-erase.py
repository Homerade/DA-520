from PIL import Image


im = Image.open("flower.jpg")
px = im.load()

w = im.width
h = im.height

for x in range(w):
    for y in range(h):
        px[x,y] = (255,255,255) # RGB VALUE

im.show()
