from PIL import Image


im = Image.open("flower.jpg")
px = im.load()

w = im.width
h = im.height

for x in range(w):
    for y in range(h):
        grey = ( px[x,y][0] + px[x,y][1] + px[x,y][2] ) / 3
        grey = round(grey)
        green = px[x,y][1]
        px[x,y] = ( grey, green, grey )

im.show()
