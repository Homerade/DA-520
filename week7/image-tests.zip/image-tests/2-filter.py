from PIL import Image
from PIL import ImageFilter

im = Image.open("flower.jpg")
im2 = im.filter( ImageFilter.GaussianBlur(50) )
im2.show()
