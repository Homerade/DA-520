from PIL import Image
from PIL import ImageDraw

im = Image.new("RGB",(100,100),(255,255,255))

circle = ImageDraw.Draw(im)
circle.ellipse( [10,10,50,50], fill=(0,100,200) )

im.show()
