from PIL import Image

# new Image
# first argument: RGB mode
# second argument: size, 100 width and 100 height
# third argument: color in rgb format (0 red, 150 green, 250 blue)
im = Image.new("RGB",(100,100),(0,150,250))
im.show()
im.save("newimg.jpg")
