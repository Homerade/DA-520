from PIL import Image
import random

im = Image.open("flower.jpg")

#loads the pixel array
px = im.load()

w = im.width
h = im.height

for x in range(w):
    for y in range(h):
        if (x > 51 and x < w-51):
            r = px[x,y][0] + px[x+50,y][0] + px[x-50,y][0]
            r /= 3
            r = round(r)
            g = px[x,y][1] + px[x+50,y][1] + px[x-50,y][1]
            g /= 3
            g = round(g)
            b = px[x,y][2] + px[x+50,y][2] + px[x-50,y][2]
            b /= 3
            b = round(b)
            px[x+random.randint(0,50),y] = ( r, g, b )

im.show()
