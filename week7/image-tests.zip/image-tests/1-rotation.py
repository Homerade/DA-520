from PIL import Image

im = Image.open("flower.jpg")
im.rotate(45).show()
